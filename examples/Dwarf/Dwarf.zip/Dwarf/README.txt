Author: Peter Gorm Larsen


This is a CML Specification of the Dwarf Signal Controller. The CML
model made in this document is a combination of a VDM-SL model produced by Peter Gorm Larsen and a CSP model produced by Jim Woodcock which again are inspired by the Dwarf Signal control
system described by Marcus Montigel, Alcatel Austria AG. These models was presented at a FM Railway
workshop. The CML model of this has been produced jointly by Peter Gorm Larsen, Jim Woodcock and Alvaro Miyazawa.



Language Version: cml