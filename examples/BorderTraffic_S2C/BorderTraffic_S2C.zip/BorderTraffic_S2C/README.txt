Author: 


This example models the traffic flow of a border crossing between two countries as a SysML model suitable for conversion by the S2C plugin.


Language Version: classic