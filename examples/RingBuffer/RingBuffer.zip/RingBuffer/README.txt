Author: 


This example demonstrates a ring buffer.


Language Version: cml