Author: Klaus Kristensen


This is an example produced entirely inside the COMPASS project. 
The example illustrates the CoSimulation example from B & O. 
This cut-down version of the example was produced by Klaus Kristensen and adapted by 
Adalberto Cajueiro to be processed using the COMPASS model checker. 


Language Version: cml