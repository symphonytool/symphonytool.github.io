Author: Alvaro Miyazawa


This simple chronometer example has been taken from the PhD work from Marcel
Oliveira in CSP that has been moved to CML by Alvaro Miyazawa. This example
is particular good to illustrate the capabilities of the CML refinement support
tool. The example contains both an olympian specification of a clock as well as
a a refined version that distributed it in multiple components.


Language Version: cml