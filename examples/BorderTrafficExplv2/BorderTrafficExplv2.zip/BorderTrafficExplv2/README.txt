Author: 


This example models the traffic flow of a border crossing between two countries in explicit style.

The Border Traffic model aims to describe a contract to which a country's Traffic Management System (TMS) must conform. The model takes a simplified view of a 1-way road which connects two countries A and B, with a border cutting the road in two. 


Language Version: classic