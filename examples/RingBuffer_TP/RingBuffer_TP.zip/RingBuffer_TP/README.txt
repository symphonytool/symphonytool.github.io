Author: 


This example demonstrates a ring buffer, and is appropriate for use with the theorem prover plugin.



Language Version: classic